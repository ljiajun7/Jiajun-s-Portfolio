module.exports={
    sessionSecret:'developmentSessionSecret'
};